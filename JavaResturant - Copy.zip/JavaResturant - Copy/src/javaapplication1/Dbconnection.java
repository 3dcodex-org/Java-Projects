/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;


import java.io.IOException;
import java.sql.*;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author MBAH
 */




public class Dbconnection {
    Connection con = null;
    public static Connection connectionDB() {
        try {
            Class.forName("org.sqlite.JDBC");
            Connection con =  DriverManager.getConnection("jdbc:sqlite:library.db");
            System.out.println("Connection successful");
            return con;
        } catch (Exception e) {
            System.out.println("Connection failed: " + e);
            return null;
        }
    }
}